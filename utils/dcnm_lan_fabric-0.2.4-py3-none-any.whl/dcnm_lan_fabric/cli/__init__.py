#!/usr/bin/env python3

from .switch import switch  # noqa: F401
