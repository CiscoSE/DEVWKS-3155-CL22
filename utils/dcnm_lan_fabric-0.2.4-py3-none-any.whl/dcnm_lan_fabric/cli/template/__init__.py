#!/usr/bin/env python3

from .actions import resource as template  # noqa:F401
